$(function() {
	// Variables globales
	var editPanel = $('#editPanel');
	var textPanel = $('#textPanel');
	var leftPanel = $('#generatedForm');
	var chosenElement = null;

	editPanel.hide();

	/*
	 * Liste des options proposées, avec leurs propriétés
	 * textPanelLabel : Texte d'explication de la valeur à entrer
	 * template : Mise en forme du l'élément qui sera inséré, avec valeur qui sera remplacée
	 * startsNewLine : Indique si on saute une ligne après cet élément
	 */
	var elementTypes =
	{
		'Label' :
		{
			'textPanelLabel' : 'Texte du label',
			'template' : '<span>$val</span> ',
			'startsNewLine' : false
		},
		'Zone de texte' :
		{
			'textPanelLabel' : 'Id de la zone de texte',
			'template' : '<input id="$val" type="text">',
			'startsNewLine' : true
		},
		'Bouton' :
		{
			'textPanelLabel' : 'Texte du bouton',
			'template' : '<button>$val</button>',
			'startsNewLine' : true
		}
	};

	// Au clic sur un des boutons
	$('#droite button').on('click', function(event) {
		editPanel.show();

		chosenElement = $(event.target).text();

		textPanel.html(
			elementTypes[chosenElement]['textPanelLabel'] + '<br>'+
			'<input type="text"> <button>OK</button>'
		);
	});

	// Au clic sur bouton "OK" (dans textPanel)
	$('#textPanel').on('click', 'button', function() {
		// Si la valeur est vide, message d'erreur
		if ($('#textPanel input').val() == '')
		{
			alert('Merci d\'entrer une valeur');
			$('#textPanel input').css('border', '2px solid red');
		}
		
		// Sinon, on crée l'élément de formulaire
		else
		{
			leftPanel.append(elementTypes[chosenElement]['template']
				.replace('$val', $('#textPanel input').val()));

			if (elementTypes[chosenElement]['startsNewLine'] == true) {
				leftPanel.append('<br><br>');
			}

			// Réinitialisation editPanel
			textPanel.html('');
			editPanel.hide();
		}
	})
});